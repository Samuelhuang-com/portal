/**
 * 退件統計 API（規格 docs/SPEC_return_reject_stats.md §6）
 * 所有呼叫統一經由 @/api/client 的 apiClient，回傳 axios Promise（呼叫端用 .data）。
 */
import apiClient from '@/api/client'

const BASE = '/return-stats'

/**
 * axios 預設把陣列序列化為 `company[]=台中`，FastAPI 的 `Query(list)` 讀不到，篩選會被忽略。
 * 改用 `indexes: null` → `company=台中&company=台中｜業務部`。
 */
const LIST_PARAMS = { paramsSerializer: { indexes: null } } as const

export type Outcome = 'rejected' | 'withdrawn' | 'approved' | 'agreed' | 'pending' | 'unknown'

export interface RRFilters {
  companies: string[]
  departments: { company: string; dept: string }[]
  form_types: string[]
  form_names: string[]
  outcomes: { value: Outcome; label: string }[]
  rejection_approvers: string[]
  data_end: string | null
}

export interface RRQuery {
  ragic_rej?: boolean
  company?: string[]
  dept?: string[]
  form_type?: string[]
  form_name?: string[]
  outcome?: string[]
  start?: string
  end?: string
  date_field?: 'apply' | 'last_sign'
  approver?: string
  rejection_approver?: string
  applicant?: string
  keyword?: string
}

export interface RRSummary {
  total: number
  counts: Record<Outcome, number>
  by_dept: ({ company: string; dept: string; total: number } & Record<Outcome, number>)[]
  last_synced_at: string | null
}

export interface RRListItem {
  id: number
  doc_no: string
  company: string
  form_type: string
  dept: string
  form_name: string
  ragic_record_id: string
  ragic_url: string
  applicant: string | null
  apply_date: string | null
  amount: number | null
  purpose: string | null
  ragic_status: string | null
  outcome: Outcome
  outcome_label: string
  outcome_reason: string
  rejection_note: string
  rejection_approver: string
  next_approver: string | null
  last_sign_date: string | null
}

export interface RRListResponse {
  total: number
  page: number
  page_size: number
  items: RRListItem[]
}

export interface RRStep {
  step_no: number
  role_field: string
  approver: string
  sign_date: string | null
  remark: string
  inferred_last: boolean
}

export interface RRDetail extends Omit<RRListItem, 'rejection_note' | 'amount'> {
  amount: number | null
  submitter: string | null
  steps: RRStep[]
  detail: Record<string, string>
}

export const getReturnStatsFilters = () =>
  apiClient.get<RRFilters>(`${BASE}/filters`)

export const getReturnStatsSummary = (params: RRQuery) =>
  apiClient.get<RRSummary>(`${BASE}/summary`, { params, ...LIST_PARAMS })

export const getReturnStatsRecords = (params: RRQuery & { page: number; page_size: number }) =>
  apiClient.get<RRListResponse>(`${BASE}/records`, { params, ...LIST_PARAMS })

export const getReturnStatsDetail = (id: number) =>
  apiClient.get<RRDetail>(`${BASE}/records/${id}`)

// 單筆重抓 Ragic 簽核步驟（失敗時 detail 為 Ragic 錯誤原文）
export const refreshReturnApproval = (id: number) =>
  apiClient.post<{ ok: boolean; steps: number; outcome: string; outcome_reason: string }>(
    `${BASE}/records/${id}/refresh-approval`, null, { timeout: 120_000 })

export const exportReturnStatsExcel = (params: RRQuery) =>
  apiClient.get<Blob>(`${BASE}/export`, { params, ...LIST_PARAMS, responseType: 'blob' })

export interface RRSyncSource {
  source_key: string
  fetched?: number
  inserted?: number
  updated?: number
  deleted_marked?: number
  error?: string
  backfill_tried?: number
  backfill_ok?: number
  backfill_empty?: number
  backfill_failed?: number
  backfill_error?: string
}

export interface RRSyncResult {
  fetched: number
  upserted: number
  errors: string[]
  sources: RRSyncSource[]
  finished_at: string
}

// 同步要抓多個 Ragic 表單，逾時放寬到 5 分鐘（預設 30 秒會誤報失敗）
export const runReturnStatsSync = () =>
  apiClient.post<RRSyncResult>(`${BASE}/sync`, null, { timeout: 300_000 })

export interface RRSourceRow {
  id: number
  source_key: string
  company: string
  form_type: string
  dept_display: string
  form_name: string
  ragic_path: string
  is_active: boolean
  record_count: number
}

// 來源啟用設定（需 return_reject_stats_manage）
export const getReturnStatsSources = () =>
  apiClient.get<RRSourceRow[]>(`${BASE}/sources`)

export const setReturnStatsSourceActive = (id: number, isActive: boolean) =>
  apiClient.patch<{ ok: boolean; is_active: boolean }>(`${BASE}/sources/${id}`, { is_active: isActive })
