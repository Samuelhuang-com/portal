/**
 * 庫存管理 API（規格 docs/SPEC_stock_management.md §8）
 * Phase 2（2026-11-17）：倉庫、料號庫存設定、庫存總覽、庫存卡、期初開帳
 * 所有請求帶 co（公司代碼 CH／OU／HO），後端依 stock_company_<代碼> 權限檢查
 */
import apiClient from '@/api/client'

const BASE = '/stock'

export interface StockCompany { code: string; name: string }
export interface StockDepartment { id: string; name: string; company_name: string }

export interface Warehouse {
  id: number
  name: string
  department_id: string | null
  department_name: string | null
  keeper_name: string | null
  status: 'active' | 'inactive' | 'counting'
  notes: string | null
  item_count: number
  amount: number | null
  has_moves: boolean
}

export interface WarehouseInput {
  name: string
  department_id?: string | null
  keeper_name?: string | null
  status: 'active' | 'inactive'
  notes?: string | null
}

export interface StockItem {
  id: number
  item_code: string
  item_name: string
  spec: string | null
  unit: string | null
  category_id: number | null
  category: string
  min_stock: number | null
  max_stock: number | null
  unit_price: number | null
  is_active: boolean
  is_stock_item: boolean
  purchase_unit: string | null
  unit_ratio: number
  abc_class: string | null
  has_setting: boolean
  total_qty: number | null
}

export interface BalanceRow {
  warehouse_id: number
  warehouse_name: string
  warehouse_status: string
  item_id: number
  item_code: string
  item_name: string
  spec: string | null
  unit: string | null
  category: string
  qty: number
  reserved_qty: number
  available_qty: number
  avg_cost: number
  amount: number
  min_stock: number | null
  max_stock: number | null
  last_move_at: string | null
  is_low: boolean
  is_over: boolean
  is_dead: boolean
}

export interface BalanceResp {
  summary: { rows: number; items: number; amount: number; low: number; dead: number }
  rows: BalanceRow[]
  data_end: string | null
  dead_days: number
}

export interface StockCardMove {
  id: number
  moved_at: string
  move_type: string
  move_type_label: string
  source_type: string
  source_id: string | null
  source_no: string | null
  in_qty: number | null
  out_qty: number | null
  unit_cost: number
  amount: number
  balance_qty: number
  balance_amount: number
  note: string | null
  created_by: string | null
  created_at: string | null
}

export interface StockCardResp {
  warehouse: { id: number; name: string; department_name: string | null }
  item: { id: number; item_code: string; item_name: string; spec: string | null; unit: string | null; min_stock: number | null; max_stock: number | null }
  balance: { qty: number; reserved_qty: number; avg_cost: number; amount: number } | null
  moves: StockCardMove[]
}

export interface Opening {
  id: number
  doc_no: string
  warehouse_id: number
  warehouse_name: string
  opening_date: string
  status: 'posted' | 'voided'
  note: string | null
  line_count: number
  total_amount: number | null
  created_by: string | null
  created_at: string | null
  voided_by: string | null
  void_reason: string | null
  lines?: { item_id: number; item_code: string; item_name: string; unit: string | null; qty: number; unit_cost: number; amount: number }[]
}

const co = (code: string) => ({ co: code })

export const fetchStockCompanies = () => apiClient.get<{ default: string; companies: StockCompany[] }>(`${BASE}/companies`)
export const fetchStockDepartments = (code: string) => apiClient.get<StockDepartment[]>(`${BASE}/departments`, { params: co(code) })
export const fetchCategories = (code: string) => apiClient.get<{ id: number; label: string }[]>(`${BASE}/categories`, { params: co(code) })

export const fetchWarehouses = (code: string) => apiClient.get<Warehouse[]>(`${BASE}/warehouses`, { params: co(code) })
export const createWarehouse = (code: string, body: WarehouseInput) => apiClient.post(`${BASE}/warehouses`, body, { params: co(code) })
export const updateWarehouse = (code: string, id: number, body: WarehouseInput) =>
  apiClient.put(`${BASE}/warehouses/${id}`, body, { params: co(code) })

export const fetchStockItems = (code: string, params: { keyword?: string; category_id?: number; stock_only?: boolean } = {}) =>
  apiClient.get<StockItem[]>(`${BASE}/items`, { params: { ...co(code), ...params } })
export const updateItemSetting = (code: string, id: number, body: { is_stock_item: boolean; purchase_unit?: string | null; unit_ratio: number; abc_class?: string | null }) =>
  apiClient.put(`${BASE}/items/${id}/setting`, body, { params: co(code) })
export const bulkItemSetting = (code: string, body: { item_ids?: number[]; category_id?: number; is_stock_item: boolean }) =>
  apiClient.post<{ updated: number; skipped_with_stock: string[] }>(`${BASE}/items/settings/bulk`, body, { params: co(code) })

export const fetchBalance = (code: string, params: { warehouse_id?: number; keyword?: string; category_id?: number; low_only?: boolean; dead_only?: boolean; include_zero?: boolean } = {}) =>
  apiClient.get<BalanceResp>(`${BASE}/balance`, { params: { ...co(code), ...params } })
export const fetchStockCard = (code: string, warehouse_id: number, item_id: number) =>
  apiClient.get<StockCardResp>(`${BASE}/stock-card`, { params: { ...co(code), warehouse_id, item_id } })
export const rebuildBalances = (code: string) =>
  apiClient.post<{ balances: number; negative_points: string[] }>(`${BASE}/balances/rebuild`, null, { params: co(code) })

export const fetchOpenings = (code: string) => apiClient.get<Opening[]>(`${BASE}/openings`, { params: co(code) })
export const fetchOpening = (code: string, id: number) => apiClient.get<Opening>(`${BASE}/openings/${id}`, { params: co(code) })
export const checkOpening = (code: string, warehouse_id: number) =>
  apiClient.get<{ allowed: boolean; reason: string }>(`${BASE}/openings-check/${warehouse_id}`, { params: co(code) })
export const createOpening = (code: string, body: { warehouse_id: number; opening_date: string; note?: string; lines: { item_id: number; qty: number; unit_cost: number }[] }) =>
  apiClient.post<{ id: number; doc_no: string; total_amount: number }>(`${BASE}/openings`, body, { params: co(code) })
export const voidOpening = (code: string, id: number, reason: string) =>
  apiClient.post(`${BASE}/openings/${id}/void`, { reason }, { params: co(code) })

/** axios 錯誤 → 後端 detail 字串 */
export const errMsg = (e: unknown, fallback: string) => {
  const d = (e as { response?: { data?: { detail?: unknown } } })?.response?.data?.detail
  return typeof d === 'string' ? d : fallback
}
