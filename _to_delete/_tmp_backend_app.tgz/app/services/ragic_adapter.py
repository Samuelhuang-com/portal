"""
Ragic API Adapter
封裝所有對 Ragic Cloud 的 HTTP 呼叫，使用 httpx async client。

重要：Ragic API Key 直接放在 Authorization header，不需要再做 base64 編碼。
格式：Authorization: Basic {API_KEY}（原始程式 ragic_client.py 的做法）
"""
import hashlib
import json
from typing import Any

import httpx

from app.core.config import settings


class RagicAdapter:
    """
    Generic adapter for any Ragic sheet.
    sheet_path format: "{tab_folder}/{sheet_index}"  e.g. "ragicsales-order-management/1"
    """

    def __init__(
        self,
        sheet_path: str | None = None,
        api_key: str | None = None,
        server_url: str | None = None,
        account: str | None = None,
    ):
        import logging as _logging
        self.api_key   = (api_key or settings.RAGIC_API_KEY or "").strip()
        self.server_url = server_url or settings.RAGIC_SERVER_URL   # e.g. "ap16.ragic.com"
        self.account   = account    or settings.ragic_account
        self.sheet_path = sheet_path or ""
        self.verify_ssl = settings.RAGIC_VERIFY_SSL

        if not self.api_key:
            _logging.getLogger(__name__).error(
                "RagicAdapter: RAGIC_API_KEY 未設定或為空。"
                "請確認 backend/.env 中有正確的 RAGIC_API_KEY 值。"
                "（sheet_path=%s, server=%s, account=%s）",
                self.sheet_path, self.server_url, self.account,
            )

    # ── Internals ─────────────────────────────────────────────────────────────

    @property
    def base_url(self) -> str:
        return f"https://{self.server_url}/{self.account}/{self.sheet_path}"

    @property
    def auth_header(self) -> dict:
        # API Key 直接放在 Basic 後面，不再做 base64 編碼
        # （與原始 ragic_client.py 保持一致）
        if not self.api_key:
            raise ValueError(
                "RAGIC_API_KEY 未設定。"
                "請在 backend/.env 中加入：RAGIC_API_KEY=<你的 Ragic API Key>"
            )
        return {
            "Authorization": f"Basic {self.api_key}",
            "Accept": "application/json",
        }

    def _base_params(self, extra: dict | None = None) -> dict:
        """共用 query params，與原始程式一致"""
        params: dict = {
            "api":     "",
            "version": settings.RAGIC_API_VERSION,
            "naming":  settings.RAGIC_NAMING,
        }
        if extra:
            params.update(extra)
        return params

    # ── Public methods ────────────────────────────────────────────────────────

    async def fetch_all(
        self,
        limit: int = 200,
        extra_params: dict | None = None,
    ) -> dict[str, Any]:
        """
        分頁拉取所有資料，回傳合併後的 dict { record_id: {field_id: value} }
        """
        all_data: dict[str, Any] = {}
        offset = 0

        async with httpx.AsyncClient(timeout=30.0, verify=self.verify_ssl) as client:
            while True:
                params = self._base_params({"limit": limit, "offset": offset})
                if extra_params:
                    params.update(extra_params)

                resp = await client.get(
                    self.base_url,
                    headers=self.auth_header,
                    params=params,
                )
                resp.raise_for_status()
                batch: dict = resp.json()

                if not isinstance(batch, dict):
                    break

                # 只保留數字 key（Ragic record ID）
                records = {k: v for k, v in batch.items() if k.lstrip("-").isdigit()}
                if not records:
                    break

                all_data.update(records)

                if len(records) < limit:
                    break
                offset += limit

        return all_data

    async def fetch_count(
        self,
        extra_params: dict | None = None,
    ) -> int:
        """
        快速計算 Ragic 記錄總數（不儲存資料，僅累計筆數）。
        分頁抓取直到最後一頁，回傳整數 count。
        """
        count = 0
        limit = 1000
        offset = 0
        async with httpx.AsyncClient(timeout=60.0, verify=self.verify_ssl) as client:
            while True:
                params = self._base_params({"limit": limit, "offset": offset})
                if extra_params:
                    params.update(extra_params)
                resp = await client.get(
                    self.base_url,
                    headers=self.auth_header,
                    params=params,
                )
                resp.raise_for_status()
                batch: dict = resp.json()
                if not isinstance(batch, dict):
                    break
                records = {k: v for k, v in batch.items() if k.lstrip("-").isdigit()}
                count += len(records)
                if len(records) < limit:
                    break
                offset += limit
        return count

    async def fetch_ids(
        self,
        extra_params: dict | None = None,
    ) -> set[str]:
        """
        抓取 Ragic 所有 record ID（不儲存欄位資料），用於與 Portal DB 做差集比對。
        """
        ids: set[str] = set()
        limit = 1000
        offset = 0
        async with httpx.AsyncClient(timeout=60.0, verify=self.verify_ssl) as client:
            while True:
                params = self._base_params({"limit": limit, "offset": offset})
                if extra_params:
                    params.update(extra_params)
                resp = await client.get(
                    self.base_url,
                    headers=self.auth_header,
                    params=params,
                )
                resp.raise_for_status()
                batch: dict = resp.json()
                if not isinstance(batch, dict):
                    break
                records = {k: v for k, v in batch.items() if k.lstrip("-").isdigit()}
                ids.update(records.keys())
                if len(records) < limit:
                    break
                offset += limit
        return ids

    async def fetch_one(self, record_id: int | str) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=15.0, verify=self.verify_ssl) as client:
            resp = await client.get(
                f"{self.base_url}/{record_id}",
                headers=self.auth_header,
                params=self._base_params(),
            )
            resp.raise_for_status()
            return resp.json()

    async def create(self, data: dict[str, Any]) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=15.0, verify=self.verify_ssl) as client:
            resp = await client.post(
                self.base_url,
                headers={**self.auth_header, "Content-Type": "application/json"},
                params=self._base_params(),
                json=data,
            )
            resp.raise_for_status()
            return resp.json()

    async def update(self, record_id: int | str, data: dict[str, Any]) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=15.0, verify=self.verify_ssl) as client:
            resp = await client.post(
                f"{self.base_url}/{record_id}",
                headers={**self.auth_header, "Content-Type": "application/json"},
                params=self._base_params(),
                json=data,
            )
            resp.raise_for_status()
            return resp.json()

    async def delete(self, record_id: int | str) -> dict[str, Any]:
        async with httpx.AsyncClient(timeout=15.0, verify=self.verify_ssl) as client:
            resp = await client.delete(
                f"{self.base_url}/{record_id}",
                headers=self.auth_header,
                params=self._base_params(),
            )
            resp.raise_for_status()
            return resp.json()

    @staticmethod
    def compute_checksum(data: dict) -> str:
        """計算資料的 SHA-256 checksum，用於判斷資料是否變更。"""
        serialized = json.dumps(data, sort_keys=True, ensure_ascii=False, default=str)
        return hashlib.sha256(serialized.encode()).hexdigest()
