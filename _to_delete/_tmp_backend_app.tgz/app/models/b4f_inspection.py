"""
整棟工務每日巡檢 - B4F  SQLAlchemy ORM Models【寬表格 Pivot 架構】

Ragic Sheet 2 結構：
  每一 Row = 一次完整巡檢場次（寬表格格式）
  場次欄位：巡檢人員、開始/結束巡檢時間、工時計算
  結果欄位：35 個設備/項目欄，各自為 正常/異常 等狀態值

DB 架構：
  b4f_inspection_batch  — 一筆 = 一次巡檢場次（對應 Ragic 一個 Row）
  b4f_inspection_item   — 一筆 = 一個設備欄位結果（Sync 時 pivot 產生，每場次 35 筆）

巡檢結果狀態（item.result_status）：
  normal    — 正常（OK）
  abnormal  — 異常
  pending   — 待處理 / 待修
  unchecked — 空白 / 未填
"""
from sqlalchemy import Column, String, Integer, DateTime, Boolean, func, Index, Text
from app.core.database import Base


class B4FInspectionBatch(Base):
    """B4F 巡檢場次（每筆 Ragic 記錄 = 一次完整巡檢）"""
    __tablename__ = "b4f_inspection_batch"

    # ── 主鍵（使用 Ragic Row ID，數字字串）──────────────────────────────────
    ragic_id = Column(String(50), primary_key=True, comment="Ragic Sheet 2 記錄 ID")

    # ── 場次欄位 ──────────────────────────────────────────────────────────────
    inspection_date = Column(String(20),  nullable=False, default="", comment="巡檢日期，從開始時間萃取 YYYY/MM/DD")
    inspector_name  = Column(String(100), nullable=False, default="", comment="巡檢人員（巡檢人員欄位）")
    start_time      = Column(String(30),  nullable=False, default="", comment="開始巡檢時間（原始值）")
    end_time        = Column(String(30),  nullable=False, default="", comment="巡檢結束時間（原始值）")
    work_hours      = Column(String(20),  nullable=False, default="", comment="工時計算（如 2 分鐘）")

    # ── 同步時間 ───────────────────────────────────────────────────────────────
    synced_at = Column(DateTime, nullable=False, server_default=func.now(),
                       onupdate=func.now(), comment="最後同步時間")

    __table_args__ = (
        Index("ix_b4f_batch_date", "inspection_date"),
    )

    def __repr__(self):
        return (
            f"<B4FInspectionBatch ragic_id={self.ragic_id} "
            f"date={self.inspection_date} inspector={self.inspector_name}>"
        )


class B4FInspectionItem(Base):
    """B4F 巡檢設備項目（每個設備欄位一筆，由 Sync 時 pivot 產生）"""
    __tablename__ = "b4f_inspection_item"

    # ── 主鍵（"{batch_ragic_id}_{seq_no}"）────────────────────────────────────
    ragic_id = Column(String(80), primary_key=True, comment="複合鍵：{batch_ragic_id}_{seq_no}")

    # ── 外鍵 ──────────────────────────────────────────────────────────────────
    batch_ragic_id = Column(String(50), nullable=False, default="",
                            comment="所屬場次 ragic_id（b4f_inspection_batch.ragic_id）")

    # ── 項目資訊 ──────────────────────────────────────────────────────────────
    seq_no    = Column(Integer,     nullable=False, default=0,   comment="項次（依 CHECK_ITEMS 順序）")
    item_name = Column(String(200), nullable=False, default="",  comment="設備/項目名稱（Ragic 欄位名）")

    # ── 巡檢結果 ──────────────────────────────────────────────────────────────
    result_raw    = Column(Text,       nullable=False, default="",          comment="原始值（正常/異常/待處理/空白；附圖時是多組 檔案ID@檔名，長度無上限）")
    result_status = Column(String(20), nullable=False, default="unchecked", comment="正規化：normal/abnormal/pending/unchecked/measure（measure＝量測/程度型欄位的記錄值，不算異常）")
    abnormal_flag = Column(Boolean,    nullable=False, default=False,        comment="是否有異常旗標")

    # ── 同步時間 ───────────────────────────────────────────────────────────────
    synced_at = Column(DateTime, nullable=False, server_default=func.now(),
                       onupdate=func.now(), comment="最後同步時間")

    __table_args__ = (
        Index("ix_b4f_item_batch",    "batch_ragic_id"),
        Index("ix_b4f_item_abnormal", "abnormal_flag"),
    )

    def __repr__(self):
        return (
            f"<B4FInspectionItem {self.ragic_id} "
            f"item={self.item_name[:20]} status={self.result_status}>"
        )
