"""
飯店例行維護 SQLAlchemy ORM Models

資料表：
  hotel_routine_pm_batch       — 保養批次主表（對應 Ragic Sheet 6）
  hotel_routine_pm_batch_item  — 保養項目明細（對應 Ragic Sheet 11，平表）

【重要】Sheet 11 結構：
  - 獨立平表，每筆記錄 = 一個保養項目
  - 透過「編號」欄位（journal_no）關聯主表批次
  - item.ragic_id 直接用 Ragic _ragicId（不需拼接）
  - is_completed 判斷：ragic_work_minutes != 0（維修工時有值即視為完成）
  - 無 location / abnormal_flag 欄位（Sheet 11 不提供）
"""
import json
from datetime import datetime
from sqlalchemy import Column, String, Integer, Text, DateTime, Boolean, func, Index
from app.core.database import Base


class HotelRoutinePMBatch(Base):
    """飯店例行維護批次主表（每月/每期一筆）"""
    __tablename__ = "hotel_routine_pm_batch"

    ragic_id         = Column(String(50),  primary_key=True,   comment="Ragic Sheet 6 記錄 ID")
    journal_no       = Column(String(50),  nullable=False, default="", comment="保養日誌編號，如 英週保202606-001")
    period_month     = Column(String(10),  nullable=False, default="", comment="保養月份，如 2026/06")
    ragic_created_at = Column(String(30),  nullable=False, default="", comment="Ragic 建立時間")
    ragic_updated_at = Column(String(30),  nullable=False, default="", comment="Ragic 更新時間")
    synced_at        = Column(DateTime,    nullable=False, server_default=func.now(),
                               onupdate=func.now(), comment="最後同步時間")

    __table_args__ = (
        Index("ix_hotel_routine_pm_batch_month", "period_month"),
    )

    def __repr__(self):
        return f"<HotelRoutinePMBatch ragic_id={self.ragic_id} journal_no={self.journal_no}>"


class HotelRoutinePMItem(Base):
    """飯店例行維護項目明細（Sheet 11 平表，每筆 = 一個保養任務）"""
    __tablename__ = "hotel_routine_pm_batch_item"

    ragic_id         = Column(String(50),  primary_key=True,   comment="Ragic Sheet 11 _ragicId（直接使用）")
    batch_ragic_id   = Column(String(50),  nullable=False, default="", comment="關聯 hotel_routine_pm_batch.ragic_id")

    # ── 保養項目基本資料 ─────────────────────────────────────────────────────
    seq_no            = Column(Integer,     nullable=False, default=0,  comment="項次")
    category          = Column(String(50),  nullable=False, default="", comment="類別：水電、空調等")
    frequency         = Column(String(20),  nullable=False, default="", comment="頻率：月/季/半年/年")
    exec_months_raw   = Column(String(100), nullable=False, default="", comment="執行月份原始文字，如「2月 5月 8月 11月」")
    exec_months_json  = Column(Text,        nullable=False, default="[]", comment="解析後整數陣列 JSON，如 [2,5,8,11]")
    task_name         = Column(String(200), nullable=False, default="", comment="保養項目描述")
    location          = Column(String(100), nullable=False, default="", comment="區域/位置（Sheet 11 無此欄，保留空值）")
    estimated_minutes = Column(Integer,     nullable=False, default=0,  comment="預估耗時（分鐘）")

    # ── 排定與執行欄位 ───────────────────────────────────────────────────────
    scheduled_date  = Column(String(10),  nullable=False, default="", comment="排定日期，如 05/06（MM/DD）")
    scheduler_name  = Column(String(100), nullable=False, default="", comment="排定人員")
    executor_name   = Column(String(100), nullable=False, default="", comment="執行人員（多人以空格分隔）")
    start_time      = Column(String(30),  nullable=False, default="", comment="保養開始時間（保養時間啟）")
    end_time        = Column(String(30),  nullable=False, default="", comment="保養結束時間（保養時間迄）")

    # ── 維修工時（Sheet 11 直接提供，作為完成判斷依據）────────────────────
    ragic_work_minutes = Column(Integer, nullable=True, comment="維修工時（分鐘）；有值 → is_completed=True")

    # ── 完成標記（ragic_work_minutes 有值時自動設為 True）────────────────
    is_completed = Column(Boolean, nullable=False, default=False,
                          comment="是否完成（ragic_work_minutes > 0 → True）")

    # ── Portal 回填欄位 ─────────────────────────────────────────────────────
    result_note      = Column(Text,    nullable=False, default="",    comment="執行結果備註")
    abnormal_flag    = Column(Boolean, nullable=False, default=False, comment="是否有異常（Portal 端維護）")
    abnormal_note    = Column(Text,    nullable=False, default="",    comment="異常說明")
    portal_edited_at = Column(DateTime, nullable=True,                comment="Portal 最後編輯時間")
    synced_at        = Column(DateTime, nullable=False, server_default=func.now(),
                               onupdate=func.now(), comment="最後同步時間")

    __table_args__ = (
        Index("ix_hotel_routine_pm_item_batch",     "batch_ragic_id"),
        Index("ix_hotel_routine_pm_item_completed", "is_completed"),
        Index("ix_hotel_routine_pm_item_abnormal",  "abnormal_flag"),
    )

    def get_exec_months(self) -> list[int]:
        try:
            return json.loads(self.exec_months_json or "[]")
        except Exception:
            return []

    def __repr__(self):
        return f"<HotelRoutinePMItem ragic_id={self.ragic_id} seq_no={self.seq_no} task={self.task_name[:20]!r}>"
