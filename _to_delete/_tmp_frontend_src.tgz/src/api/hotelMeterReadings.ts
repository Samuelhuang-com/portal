/**
 * 每日數值登錄表 API 封裝
 * Prefix: /api/v1/hotel-meter-readings
 */
import apiClient from '@/api/client'

const BASE = '/hotel-meter-readings'

// ── 型別 ─────────────────────────────────────────────────────────────────────

export interface HotelMRSheetConfig {
  key:         string
  title:       string
  ragic_url:   string
  description: string
}

/** 單一 Sheet 的 Dashboard 統計 */
export interface HotelMRSheetSummary {
  key:                string
  title:              string
  ragic_url:          string
  has_today:          boolean             // 今日（或末日）是否已登錄
  is_current_month:   boolean             // 是否為當月查詢
  month_count:        number              // 查詢月份登錄筆數
  latest_record_date: string              // 查詢月份內最近登錄日期 YYYY/MM/DD
  missing_days:       string[]            // 缺漏日期清單
  missing_count:      number              // 缺漏天數
  trend_7d:           HotelMRTrendPoint[] // 近 7 天趨勢
  has_data:           boolean             // 是否有任何資料
}

export interface HotelMRTrendPoint {
  date:       string   // YYYY/MM/DD
  has_record: boolean  // 當日是否有登錄
}

/** 跨 Sheet Dashboard 總覽 */
export interface HotelMRDashboardSummary {
  month:       string   // YYYY-MM 查詢月份
  target_date: string   // 向後相容
  year_month:  string   // YYYY/MM
  sheets:      HotelMRSheetSummary[]
}

/** 登錄清單（列表頁）每一列資料 */
export interface HotelMRBatchRow {
  id:            string
  record_date:   string
  recorder_name: string
  start_time:    string
  end_time:      string
  work_hours:    string
  synced_at:     string
  ragic_url:     string
}

/** 月曆格單日資料 */
export interface HotelMRCalendarCell {
  has_record:      boolean
  completion_rate: number
  abnormal_count:  number
  pending_count:   number
}

/** 月曆格單 Sheet 行資料 */
export interface HotelMRCalendarRow {
  key:   string
  label: string
  daily: Record<string, HotelMRCalendarCell>
}

/** 月曆格 API 回傳 */
export interface HotelMRCalendarResponse {
  year:    number
  month:   number
  max_day: number
  rows:    HotelMRCalendarRow[]
}

// ── API 函式 ──────────────────────────────────────────────────────────────────

/**
 * 取得全體每日數值登錄 Dashboard 統計（跨 Sheet）
 * @param month  查詢月份，YYYY-MM 格式（如 "2026-05"）。不填則後端自動使用當月。
 */
export async function fetchHotelMeterDashboardSummary(
  params?: { month?: string; target_date?: string },
): Promise<HotelMRDashboardSummary> {
  const res = await apiClient.get<HotelMRDashboardSummary>(
    `${BASE}/dashboard/summary`,
    { params: params ?? {} },
  )
  return res.data
}

/**
 * 取得指定 Sheet 指定月份的登錄清單
 */
export async function fetchHotelMeterBatches(
  sheetKey: string,
  params: { year_month?: string; search?: string },
): Promise<HotelMRBatchRow[]> {
  const res = await apiClient.get<HotelMRBatchRow[]>(
    `${BASE}/${sheetKey}/batches`,
    { params },
  )
  return res.data
}

/**
 * 取得 4 張 Sheet 設定清單
 */
export async function fetchHotelMeterSheets(): Promise<HotelMRSheetConfig[]> {
  const res = await apiClient.get<HotelMRSheetConfig[]>(`${BASE}/sheets`)
  return res.data
}

/**
 * 觸發指定 Sheet Ragic 同步（背景執行）
 */
export async function syncHotelMeterFromRagic(sheetKey: string): Promise<void> {
  await apiClient.post(`${BASE}/${sheetKey}/sync`)
}

/**
 * 觸發全部 4 張 Sheet Ragic 同步（背景執行）
 */
export async function syncHotelMeterAllFromRagic(): Promise<void> {
  await apiClient.post(`${BASE}/sync/all`)
}

/**
 * 取得月曆格資料（MonthlyCalendarGrid 用）
 * @param year  年份（如 2026）
 * @param month 月份 1-12（如 5）
 */
export async function fetchHotelMeterCalendar(
  year: number,
  month: number,
): Promise<HotelMRCalendarResponse> {
  const res = await apiClient.get<HotelMRCalendarResponse>(
    `${BASE}/daily-calendar`,
    { params: { year, month } },
  )
  return res.data
}
