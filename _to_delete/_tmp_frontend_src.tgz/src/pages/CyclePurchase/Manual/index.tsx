/**
 * 週期採購（週採）— 使用手冊（/cycle-purchase/manual）
 *
 * 內容在 content.ts，這裡只負責版面：目錄、全文搜尋、區塊渲染。
 *
 * 互動功能：
 *   1. 左側目錄，點擊跳轉
 *   2. 全文搜尋：篩掉不相關小節並高亮命中字
 *   3. 對應到實際頁面的小節，標題右側有「前往此功能」按鈕
 *
 * ⚠️ 刻意**不重用** `pages/Realtime/Manual` 或 `pages/Opera/Manual` ——
 *    三個模組彼此獨立，重用會讓其中一邊的改動波及另外兩邊。
 *    版面骨架與 Realtime 版相同（複製而非引用），是刻意的重複；
 *    Opera 版多出來的「即時抓資料庫數字」「章節實作狀態」週採用不到。
 *
 * 權限：與 Samuel 確認開放給**所有週採使用者**（MainLayout 用 permissionKeys
 *    OR 涵蓋全部 8 個週採權限）。手冊是教人怎麼用的，卡權限會讓最需要它的
 *    填單人看不到，所以不另立新的 permission key、路由也不加 PermissionGuard
 *    （與週採其他路由一致，存取控制在選單與後端端點）。
 */
import React, { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Alert, Anchor, Button, Card, Col, Empty, Input, Row, Space, Table, Tag, Typography,
} from 'antd'
import {
  ArrowRightOutlined, BookOutlined, ExclamationCircleOutlined, ExportOutlined,
  InfoCircleOutlined, SearchOutlined, StopOutlined,
} from '@ant-design/icons'

import {
  MANUAL, MANUAL_META, subSectionText,
  type Block, type Section, type SubSection,
} from './content'

const { Title, Text, Paragraph } = Typography

/** CLAUDE.md 受保護色：品牌主色／輔色／異常紅。刻意在本檔宣告而非跨模組 import。 */
const BRAND = '#1B3A5C'
const ACCENT = '#4BA8E8'
const RED = '#e74c3c'

/** Portal Header 為 sticky、實際高度 64px，再留 12px 空隙 */
const STICKY_TOP = 76

// ── 行內樣式：**粗體** 與 `等寬` ─────────────────────────────────────────────
// 只用兩個最常見的 Markdown 記號就夠，不值得為此引入 markdown 套件。
function renderInline(text: string, keyword: string): React.ReactNode {
  const tokens = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g).filter(Boolean)
  return tokens.map((tok, i) => {
    if (tok.startsWith('**') && tok.endsWith('**')) {
      return <Text strong key={i}>{highlight(tok.slice(2, -2), keyword)}</Text>
    }
    if (tok.startsWith('`') && tok.endsWith('`')) {
      return <Text code key={i} style={{ fontSize: 12 }}>{highlight(tok.slice(1, -1), keyword)}</Text>
    }
    return <React.Fragment key={i}>{highlight(tok, keyword)}</React.Fragment>
  })
}

function highlight(text: string, keyword: string): React.ReactNode {
  if (!keyword) return text
  const idx = text.toLowerCase().indexOf(keyword.toLowerCase())
  if (idx < 0) return text
  return (
    <>
      {text.slice(0, idx)}
      <mark style={{ background: '#fff1b8', padding: '0 2px' }}>
        {text.slice(idx, idx + keyword.length)}
      </mark>
      {text.slice(idx + keyword.length)}
    </>
  )
}

// ── 區塊渲染 ─────────────────────────────────────────────────────────────────

const BlockView: React.FC<{ block: Block; keyword: string }> = ({ block, keyword }) => {
  switch (block.t) {
    case 'p':
      return (
        <Paragraph style={{ marginBottom: 10 }}>
          {renderInline(block.text, keyword)}
        </Paragraph>
      )

    case 'ul':
      return (
        <ul style={{ marginBottom: 10, paddingInlineStart: 22 }}>
          {block.items.map((it, i) => (
            <li key={i} style={{ marginBottom: 4 }}>{renderInline(it, keyword)}</li>
          ))}
        </ul>
      )

    case 'ol':
      return (
        <ol style={{ marginBottom: 10, paddingInlineStart: 22 }}>
          {block.items.map((it, i) => (
            <li key={i} style={{ marginBottom: 4 }}>{renderInline(it, keyword)}</li>
          ))}
        </ol>
      )

    case 'note':
      return (
        <Alert
          type="info" showIcon icon={<InfoCircleOutlined />}
          style={{ marginBottom: 10 }}
          message={<span style={{ fontSize: 13 }}>{renderInline(block.text, keyword)}</span>}
        />
      )

    case 'caution':
      return (
        <Alert
          type="warning" showIcon icon={<ExclamationCircleOutlined />}
          style={{ marginBottom: 10 }}
          message={<span style={{ fontSize: 13 }}>{renderInline(block.text, keyword)}</span>}
        />
      )

    case 'wrong':
      // 常見誤解：用受保護色 #fff5f5 / #ffccc7（CLAUDE.md 保護色）
      return (
        <div style={{
          background: '#fff5f5', border: '1px solid #ffccc7', borderRadius: 6,
          padding: '8px 12px', marginBottom: 10, fontSize: 13,
        }}>
          <StopOutlined style={{ color: RED, marginInlineEnd: 6 }} />
          {renderInline(block.text, keyword)}
        </div>
      )

    case 'table':
      return (
        <>
          <Table
            size="small"
            style={{ marginBottom: 10 }}
            pagination={false}
            rowKey={(_, i) => String(i)}
            dataSource={block.rows.map((r, i) => {
              const o: any = { _k: i }
              r.forEach((c, j) => { o[`c${j}`] = c })
              return o
            })}
            columns={block.head.map((h, j) => ({
              title: h || ' ',
              dataIndex: `c${j}`,
              width: j === 0 ? 180 : undefined,
              render: (v: string) => (
                <span style={{ fontSize: 13 }}>{renderInline(v ?? '', keyword)}</span>
              ),
            }))}
          />
          {block.caption && (
            <Text type="secondary" style={{ fontSize: 12 }}>{block.caption}</Text>
          )}
        </>
      )

    case 'diagram': {
      // 圖檔由後端 /docs-static 提供（portal/docs/），比照合約模組說明指南的 iframe 作法。
      // theme=light：Portal 是淺色版面，避免圖跟著作業系統切成深色。
      // embed=1：手冊內只顯示圖本體（Archify 內建嵌入模式，隱藏工具列與說明卡片）；
      // 「新視窗開啟」才給完整版（含 Export、說明卡片）。
      const url = `${block.src}?theme=light`
      const embedUrl = `${url}&embed=1`
      return (
        <div style={{ marginBottom: 10 }}>
          <div style={{
            display: 'flex', justifyContent: 'space-between',
            alignItems: 'center', marginBottom: 6,
          }}>
            <Text type="secondary" style={{ fontSize: 13 }}>{highlight(block.title, keyword)}</Text>
            <Button size="small" icon={<ExportOutlined />} onClick={() => window.open(url, '_blank')}>
              新視窗開啟
            </Button>
          </div>
          <iframe
            src={embedUrl}
            title={block.title}
            loading="lazy"
            style={{
              width: '100%',
              height: block.height ?? 640,
              border: '1px solid #e0e6ed',
              borderRadius: 6,
            }}
          />
          {block.caption && (
            <Text type="secondary" style={{ fontSize: 12, display: 'block', marginTop: 4 }}>
              {renderInline(block.caption, keyword)}
            </Text>
          )}
        </div>
      )
    }

    default:
      return null
  }
}

// ── 主頁面 ───────────────────────────────────────────────────────────────────

const CpManualPage: React.FC = () => {
  const navigate = useNavigate()
  const [keyword, setKeyword] = useState('')

  /** 搜尋：只保留有命中的小節；章節若整章沒命中就整章不顯示 */
  const filtered: Section[] = useMemo(() => {
    const kw = keyword.trim().toLowerCase()
    if (!kw) return MANUAL
    return MANUAL
      .map((sec) => ({
        ...sec,
        subs: sec.subs.filter((sub) => subSectionText(sub).toLowerCase().includes(kw)),
      }))
      .filter((sec) => sec.subs.length > 0 || sec.title.toLowerCase().includes(kw))
  }, [keyword])

  const hitCount = useMemo(
    () => filtered.reduce((n, s) => n + s.subs.length, 0),
    [filtered],
  )

  return (
    <div style={{ padding: 24 }}>
      {/* ── 標題 ─────────────────────────────────────────────────────── */}
      <Space direction="vertical" size={4} style={{ marginBottom: 16 }}>
        <Space size={12} wrap>
          <BookOutlined style={{ color: ACCENT, fontSize: 20 }} />
          <Title level={4} style={{ margin: 0, color: BRAND }}>{MANUAL_META.title}</Title>
          <Tag>v{MANUAL_META.version}</Tag>
          <Text type="secondary" style={{ fontSize: 12 }}>更新於 {MANUAL_META.updated}</Text>
        </Space>
        <Text type="secondary" style={{ fontSize: 13 }}>{MANUAL_META.subtitle}</Text>
      </Space>

      <Alert
        type="warning"
        showIcon
        style={{ marginBottom: 16 }}
        message="讀這份手冊之前，先知道這件事"
        description={
          <span style={{ fontSize: 13 }}>{renderInline(MANUAL_META.disclaimer, '')}</span>
        }
      />

      <Row gutter={16}>
        {/* ── 左側目錄 ───────────────────────────────────────────────── */}
        <Col xs={24} md={6}>
          <div style={{ position: 'sticky', top: STICKY_TOP }}>
            <Card size="small" title="目錄">
              <Anchor
                affix={false}
                targetOffset={STICKY_TOP}
                items={filtered.map((sec) => ({
                  key: sec.id,
                  href: `#${sec.id}`,
                  title: <span style={{ fontSize: 13 }}>{sec.title}</span>,
                }))}
              />
            </Card>
          </div>
        </Col>

        {/* ── 右側內容 ───────────────────────────────────────────────── */}
        <Col xs={24} md={18}>
          <Card size="small" style={{ marginBottom: 16 }}>
            <Input
              allowClear
              size="large"
              prefix={<SearchOutlined />}
              placeholder="搜尋手冊內容，例如「關閉」「分批驗收」「分攤」"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
            />
            {keyword && (
              <Text type="secondary" style={{ fontSize: 12, marginTop: 8, display: 'block' }}>
                命中 {hitCount} 個小節
              </Text>
            )}
          </Card>

          {filtered.length === 0 ? (
            <Empty description={`找不到與「${keyword}」相關的內容`} />
          ) : (
            filtered.map((sec) => (
              <Card
                key={sec.id}
                id={sec.id}
                size="small"
                style={{ marginBottom: 16, scrollMarginTop: STICKY_TOP }}
                title={<Text strong style={{ color: BRAND }}>{sec.title}</Text>}
              >
                {sec.intro && (
                  <Paragraph type="secondary" style={{ fontSize: 13 }}>
                    {renderInline(sec.intro, keyword)}
                  </Paragraph>
                )}

                {sec.subs.map((sub: SubSection) => (
                  <div key={sub.id} id={sub.id} style={{ marginBottom: 18 }}>
                    <Space size={8} wrap style={{ marginBottom: 6 }}>
                      <Text strong style={{ fontSize: 14 }}>
                        {highlight(sub.title, keyword)}
                      </Text>
                      {sub.route && (
                        <Button
                          size="small" type="link" icon={<ArrowRightOutlined />}
                          onClick={() => navigate(sub.route!)}
                          style={{ color: ACCENT, paddingInline: 4 }}
                        >
                          前往此功能
                        </Button>
                      )}
                    </Space>
                    {sub.blocks.map((b, i) => (
                      <BlockView key={i} block={b} keyword={keyword} />
                    ))}
                  </div>
                ))}
              </Card>
            ))
          )}

          <Text type="secondary" style={{ fontSize: 12 }}>
            欄位層級的完整規格：
            <Text code style={{ fontSize: 11 }}>ragic-cycle-purchase/docs/欄位規格.md</Text>
            　規劃背景：
            <Text code style={{ fontSize: 11 }}>ragic-cycle-purchase/docs/週期採購_Portal規劃評估_v1.1.md</Text>
          </Text>
        </Col>
      </Row>
    </div>
  )
}

export default CpManualPage
